#!/bin/bash
# Backup đầy đủ → Git repo /var/www/backup-repo → push GitHub
set -euo pipefail

REPO_DIR="/var/www/backup-repo"
LOCAL_CACHE="/var/www/backups"
DATE_TAG=$(date +%Y-%m-%d)
DATE_STAMP=$(date +%Y%m%d_%H%M%S)
SNAP_DIR="$REPO_DIR/daily/$DATE_TAG"
KEEP_DAYS=30
LOG_FILE="$LOCAL_CACHE/backup-git.log"
ENV_FILE="/var/www/backend/.env"
GIT_REMOTE="${GIT_BACKUP_REMOTE:-git@github.com-backup:hoangbom2026-coder/mbs-daily-backup.git}"
GIT_BRANCH="${GIT_BACKUP_BRANCH:-main}"

log() { echo "[$(date '+%F %T')] $*" | tee -a "$LOG_FILE"; }

mkdir -p "$SNAP_DIR" "$LOCAL_CACHE" "$REPO_DIR/daily"

# --- Đọc DB password ---
if [[ ! -f "$ENV_FILE" ]]; then
  log "ERROR: Không tìm thấy $ENV_FILE"
  exit 1
fi
DB_PASS=$(grep '^DB_PASSWORD=' "$ENV_FILE" | cut -d= -f2-)
DB_NAME=$(grep '^DB_NAME=' "$ENV_FILE" | cut -d= -f2- || echo mbays_game)
DB_USER=$(grep '^DB_USER=' "$ENV_FILE" | cut -d= -f2- || echo root)

log "=== Bắt đầu backup $DATE_TAG ==="

# --- 1. Database full dump ---
log "Dump MySQL $DB_NAME..."
mysqldump -u "$DB_USER" -p"$DB_PASS" \
  --single-transaction \
  --quick \
  --routines \
  --triggers \
  --events \
  --hex-blob \
  --default-character-set=utf8mb4 \
  "$DB_NAME" | gzip -9 > "$SNAP_DIR/database.sql.gz"

cp "$SNAP_DIR/database.sql.gz" "$LOCAL_CACHE/mysql_${DATE_STAMP}.sql.gz"
ln -sfn "mysql_${DATE_STAMP}.sql.gz" "$LOCAL_CACHE/LATEST-mysql-backup.sql.gz"

# --- 2. Uploads & flags ---
log "Đóng gói uploads..."
tar -czf "$SNAP_DIR/uploads.tar.gz" -C /var/www/backend/src/public uploads 2>/dev/null || true
cp "$SNAP_DIR/uploads.tar.gz" "$LOCAL_CACHE/uploads_${DATE_STAMP}.tar.gz" 2>/dev/null || true
ln -sfn "uploads_${DATE_STAMP}.tar.gz" "$LOCAL_CACHE/LATEST-uploads-backup.tar.gz" 2>/dev/null || true

log "Đóng gói flags..."
if [[ -d /var/www/backend/src/public/flag ]]; then
  tar -czf "$SNAP_DIR/flags.tar.gz" -C /var/www/backend/src/public flag
else
  tar -czf "$SNAP_DIR/flags.tar.gz" --files-from /dev/null
fi

# --- 3. Configs hệ thống ---
log "Đóng gói configs..."
TMP_CFG=$(mktemp -d)
mkdir -p "$TMP_CFG/backend" "$TMP_CFG/nginx" "$TMP_CFG/systemd" "$TMP_CFG/mysql"
cp "$ENV_FILE" "$TMP_CFG/backend/.env"
cp /etc/nginx/sites-available/mbay "$TMP_CFG/nginx/mbay" 2>/dev/null || true
cp /etc/systemd/system/mbs-backend.service "$TMP_CFG/systemd/" 2>/dev/null || true
cp /etc/mysql/mysql.conf.d/99-low-memory.cnf "$TMP_CFG/mysql/" 2>/dev/null || true
cp /var/www/scripts/backup-git.sh "$TMP_CFG/scripts-backup-git.sh" 2>/dev/null || true
tar -czf "$SNAP_DIR/configs.tar.gz" -C "$TMP_CFG" .
rm -rf "$TMP_CFG"

# --- 4. Manifest ---
log "Tạo manifest..."
DB_SIZE=$(stat -c%s "$SNAP_DIR/database.sql.gz")
UP_SIZE=$(stat -c%s "$SNAP_DIR/uploads.tar.gz" 2>/dev/null || echo 0)
DB_SHA=$(sha256sum "$SNAP_DIR/database.sql.gz" | awk '{print $1}')
UP_SHA=$(sha256sum "$SNAP_DIR/uploads.tar.gz" 2>/dev/null | awk '{print $1}' || echo "none")

TABLE_STATS=$(mysql -u "$DB_USER" -p"$DB_PASS" -N -e "
  SELECT CONCAT('{\"table\":\"', table_name, '\",\"rows\":', IFNULL(table_rows,0), '}')
  FROM information_schema.tables
  WHERE table_schema='$DB_NAME' ORDER BY table_name;
" 2>/dev/null | paste -sd, - )
TABLE_STATS=${TABLE_STATS:-}
TABLE_JSON="[${TABLE_STATS}]"

cat > "$SNAP_DIR/manifest.json" <<EOF
{
  "date": "$DATE_TAG",
  "timestamp": "$(date -Iseconds)",
  "hostname": "$(hostname)",
  "database": "$DB_NAME",
  "files": {
    "database.sql.gz": { "bytes": $DB_SIZE, "sha256": "$DB_SHA" },
    "uploads.tar.gz": { "bytes": $UP_SIZE, "sha256": "$UP_SHA" }
  },
  "tables": $TABLE_JSON,
  "services": {
    "mysql": "$(systemctl is-active mysql 2>/dev/null || echo unknown)",
    "nginx": "$(systemctl is-active nginx 2>/dev/null || echo unknown)",
    "backend": "$(systemctl is-active mbs-backend 2>/dev/null || echo unknown)"
  }
}
EOF

# --- 5. Xóa snapshot cũ (giữ KEEP_DAYS) ---
find "$REPO_DIR/daily" -mindepth 1 -maxdepth 1 -type d ! -name "$DATE_TAG" -mtime +$KEEP_DAYS -exec rm -rf {} + 2>/dev/null || true
find "$LOCAL_CACHE" -name 'mysql_*.sql.gz' -mtime +7 -delete 2>/dev/null || true
find "$LOCAL_CACHE" -name 'uploads_*.tar.gz' -mtime +7 -delete 2>/dev/null || true

# --- 6. Git commit & push ---
cd "$REPO_DIR"
if [[ ! -d .git ]]; then
  git init -b "$GIT_BRANCH"
  git config user.email "backup@mbs.vps"
  git config user.name "MBS Backup Bot"
fi

git add -A
if git diff --cached --quiet; then
  log "Không có thay đổi — bỏ qua commit"
else
  git commit -m "backup: $DATE_TAG $(date +%H:%M) — db+uploads+configs"
  log "Git commit OK"
fi

if git remote get-url origin &>/dev/null; then
  if GIT_SSH_COMMAND="ssh -i /root/.ssh/mbs_backup_deploy -o StrictHostKeyChecking=accept-new" \
     git push -u origin "$GIT_BRANCH" 2>>"$LOG_FILE"; then
    log "Git push OK → origin/$GIT_BRANCH"
  else
    log "WARN: Git push thất bại — chạy /var/www/scripts/setup-backup-git.sh để cấu hình SSH"
  fi
else
  log "WARN: Chưa có git remote — chạy setup-backup-git.sh"
fi

log "=== Hoàn tất backup $DATE_TAG ==="
